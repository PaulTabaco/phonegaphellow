/**
 * Created by paul on 24.11.16.
 */
function buttonClick(){
    console.log("Message here!")
}